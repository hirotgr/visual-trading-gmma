# **GMMAライン分析：価格線と二種のリボンを用いた幾何学的トレード戦略**

本ドキュメントでは、ローソク足（OHLCデータ）の情報が制限された環境下において、GMMAのライン（価格線、短期線群、長期線群）の形状と相互関係のみから「市場心理」と「トレンドの継続性」を読み解き、売買判断を行うための定量的・定性的手法を規定する。

## **1\. チャート要素の定義と市場心理の解釈**

本戦略では、各ラインを以下の市場参加者の行動として定義する 。

* **プライスライン（シアン）**: 「現在の市場合意価格」。瞬時のセンチメントを反映する。  
* **短期線群（赤紫 / EMA 3-15）**: 「投機家（トレーダー）の挙動」。短期的な利益期待と感情を可視化する 。  
* **長期線群（オレンジ / EMA 30-60）**: 「投資家の本質的同意」。トレンドの基盤となる支持・抵抗帯を形成する 。

## ---

**2\. トレンド判定の幾何学的アルゴリズム**

ローソク足のパターン（ピンバー、包み足等）が使えない場合、以下の「序列」と「形状」を判定基準とする 。

### **2.1 強気トレンド（上昇）の定義**

以下の3条件が揃った状態を「信頼性の高い上昇トレンド」と定義する 。

1. **序列**: 上から「プライスライン ＞ 短期リボン ＞ 長期リボン」の順に並んでいる。  
2. **傾斜**: 全てのラインが右肩上がりの正の傾きを持っている。  
3. **拡散（エクスパンション）**: 各リボンの幅（厚み）が広がり、リボン間のギャップ（乖離）が拡大している 。

### **2.2 弱気トレンド（下降）の定義**

1. **序列**: 上から「長期リボン ＞ 短期リボン ＞ プライスライン」の順に並んでいる 。  
2. **傾斜**: 全てのラインが右肩下がりの負の傾きを持っている。  
3. **拡散**: 各リボンが扇状に広がりながら下方へ向かっている 。

## ---

**3\. 売買判断（エントリー・エグジット）のタイミング**

ラインの「交差（クロス）」と「収束（コンプレッション）」を主要なトリガーとする 。

### **3.1 エントリー戦略**

* **プルバック（押し目買い）**:  
  * 上昇トレンド中にプライスラインが一時的に下落し、赤紫の短期リボンを割り込む。  
  * プライスラインがオレンジの長期リボンの「上端（EMA30）」または「内部」で反発する。  
  * プライスラインが再び短期リボンの最上位線を上抜けた瞬間をエントリーとする 。  
* **コンプレッション・ブレイクアウト**:  
  * 12本のEMAが一本の線のように密着し、横ばいになる（エネルギー充填）。  
  * プライスラインがこの塊を突き抜け、同時にリボンが上下に拡散を開始した瞬間をトリガーとする 。

### **3.2 エグジット（利益確定・損切り）戦略**

* **段階的利確**:  
  * プライスラインが赤紫の短期リボンの内部に深く入り込んだ際、勢いの減速と見なし一部決済する。  
  * 短期リボンが収束（スクイーズ）を始めたら、トレンドの終焉を警戒する 1。  
* **全決済（トレンド崩壊）**:  
  * 短期リボンが長期リボンを完全に逆走（クロス）したとき。  
* **損切り（最終防衛線）**:  
  * 長期リボンの最も外側のライン（EMA60）を価格が完全に割り込んだ場合、即座に撤退する 1。

## ---

**4\. 指標の定量化：代表線による管理**

目視による主観を排除するため、以下の代表線を規定し、距離と角度を計測する手法が有効である。

| 規定する線 | 対応するEMA | 役割 |
| :---- | :---- | :---- |
| **先行代表線** | EMA 3 | プライスラインの平滑化、短期反転の初動捕捉 |
| **支持代表線** | EMA 30 | 長期リボンの入口（サポートの一次境界） |
| **基盤代表線** | EMA 60 | トレンド継続の「最終防衛線」 |

### **定量化のポイント**

1. **リボンの厚み**: (短期最高EMA \- 短期最低EMA) の値をボラティリティとして算出。  
2. **トレンド乖離率**: (EMA 3 \- EMA 60\) の距離を測定。この数値が減少に転じることは、長期投資家に対するトレーダーの期待値が低下していることを意味する 。  
3. **収束係数**: 12本全体の標準偏差を算出し、過去最低水準まで低下した際を「ブレイクアウト待機状態」と判定する 。

## ---

**5\. 運用上の注意**

* **ダマシの回避**: 短期リボンのクロスだけでは不十分であり、必ず「長期リボンの傾き」と「拡散の有無」をセットで確認する 。  
* **遅行性の認識**: GMMAは移動平均に基づいているため、急激なV字回復などには対応が遅れる特性がある。これを補うため、ラインの「角度の変化」に注目することが肝要である 。

#### **引用文献**

1. Guppy Multiple Moving Average (GMMA): Calculation & Trading ..., 2月 21, 2026にアクセス、 [https://www.litefinance.org/blog/for-beginners/best-technical-indicators/guppy-multiple-moving-average/](https://www.litefinance.org/blog/for-beginners/best-technical-indicators/guppy-multiple-moving-average/)  
2. Lesson \#9 Adapting Your Exit Strategy to Changing Market Conditions \- MarketMates, 2月 21, 2026にアクセス、 [https://marketmates.com/learn/forex-course/lesson-9-adapting-your-exit-strategy-to-changing-market-conditions/](https://marketmates.com/learn/forex-course/lesson-9-adapting-your-exit-strategy-to-changing-market-conditions/)  
3. How to Trend Trade with Guppy Multiple Moving Average (GMMA) \- ifcci, 2月 21, 2026にアクセス、 [https://www.ifcci.org.my/courses/learn-forex-course-03/lessons/how-to-trend-trade-with-guppy-multiple-moving-average-gmma/](https://www.ifcci.org.my/courses/learn-forex-course-03/lessons/how-to-trend-trade-with-guppy-multiple-moving-average-gmma/)  
4. Gmma — Indicators and Strategies — TradingView — India, 2月 21, 2026にアクセス、 [https://in.tradingview.com/scripts/gmma/](https://in.tradingview.com/scripts/gmma/)  
5. How to Ride the Trend Wave with Guppy Moving Averages (GMMA) \- Babypips.com, 2月 21, 2026にアクセス、 [https://www.babypips.com/z/learn/forex/guppy-multiple-moving-average](https://www.babypips.com/z/learn/forex/guppy-multiple-moving-average)  
6. Daryl Guppy Trend Trading, 2月 21, 2026にアクセス、 [https://mirante.sema.ce.gov.br/Download\_PDFS/Resources/603317/mL6G6D/DarylGuppyTrendTrading.pdf](https://mirante.sema.ce.gov.br/Download_PDFS/Resources/603317/mL6G6D/DarylGuppyTrendTrading.pdf)